Allowed Uploads
===============

For OJS/OMP/OPS 3.4.0

The plugin enables the editor to choose which file extensions are allowed in their journal. NOTE! This is *not* a security plugin. Make sure that your files directory is not a subdirectory of your OJS/OMP/OPS installation. For more details read the OJS/OMP/OPS installation instructions.

Copy the plugin folder to plugins/generic/ and enable it. Edit the plugin settings and add a list semicolon separated list of allowed filetypes, for example **doc; docx; pdf; gif; jpg;**.


TODO
- Add checks and validation when saving the allowed file extensions list

***
Plugin created by The Federation of Finnish Learned Societies (https://tsv.fi/en/).
***
